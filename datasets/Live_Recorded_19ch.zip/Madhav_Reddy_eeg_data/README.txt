
Madhav Reddy EEG Dataset

Dataset Structure:
- Eyes_Closed -> label 0
- Task -> label 1

This dataset was reorganized for supervised deep learning training.
Original EDF data was preserved without modification.

Recommended Usage:
- EEGNet
- CNN
- CNN + LSTM

Training Type:
Binary Classification
